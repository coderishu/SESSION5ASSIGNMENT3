package com.example.ishumishra97.session5assignment3;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Created by admin on 8/23/2015.
 */
public class Acadgild extends Activity {

    TextView mentorName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_acadgild);

        mentorName=(TextView)findViewById(R.id.textView);

        Bundle bundle=getIntent().getExtras();

        if(bundle!=null){
            String course=bundle.getString(MainActivity. BUNDLE_KEY_COURSE);

            if(course.equalsIgnoreCase("Android App Development")){
                mentorName.setText("Pushpalatha, Asha, Ranjith");
            }
            else if(course.equalsIgnoreCase("Front End Web Development")){
                mentorName.setText("Sumit, Jinto");
            }
        }
    }
}
